<html>

<form action='ProjectZoekfunctie.php' method='POST'>
<fieldset>
Search: <input type='text' name='sqry' size='40' placeholder='Tags, Hashtags, Posts, Users' />
<input type='submit' name='submit' value="search" />
</fieldset>

</form>

</html>

<?php
include 'DBCon.php';


if(isset($_POST['submit'])) {

    $searchRequest = $_POST['sqry'];
   
    $searchResults = array();
    $resultCount = 0;


    $usernameQuery = "SELECT * FROM users WHERE username LIKE '%$searchRequest%'";
    if($result = mysqli_query($conn, $usernameQuery)) {
        while($row = mysqli_fetch_assoc($result)) {
            $searchResults[$resultCount++] = $row['username'];
        }

         mysqli_free_result($result);
    }

    $recipeQuery = "SELECT * FROM posts WHERE recipe LIKE '%$searchRequest%'";
    if($result = mysqli_query($conn, $postsQuery)) {
        while($row = mysqli_fetch_assoc($result)) {
            $searchResults[$resultCount++] = $row['recipe'];
        }

         mysqli_free_result($result);
    }

  $titleQuery = "SELECT * FROM posts WHERE title LIKE '%$searchRequest%'";
    if($result = mysqli_query($conn, $titleQuery)) {
        while($row = mysqli_fetch_assoc($result)) {
            $searchResults[$resultCount++] = $row['title'];
        }

         mysqli_free_result($result);
    }

    for ($i=0; $i < sizeof($searchResults); $i++) { 
        echo "<h4>" .$searchResults[$i] . "</h4>";
    }


}


closeDB();

?>